<?php
/****  
 * CLIENTE WebService 
 * Josseline Lemus
 * está carpeta del iva para que cargue el formulario de productos, con sus campos;
 * correspondientes, con su codino, nombre del producto, precio.
 *********/ 
if (isset($_POST["cod"])) {

	date_default_timezone_set("America/El_Salvador");
	require_once('nusoap/lib/nusoap.php');
	$wsdl = "http://localhost/examen/ws.php?wsdl";
	$client = new nusoap_client($wsdl,"wsdl");
	$err = $client->getError();
	if ($err) {
		echo '<h2>Constructor error</h2><pre>' . $err . '</pre>';
		exit();
	}
	$parametros = array(
        'cod' =>$_POST["cod"],
        'nombre' => $_POST["nombre"],
        'precio' => $_POST["precio"],
    );

	$reult = $client->call('totalIva',$parametros);

	?>
	<!DOCTYPE html>
	<html lang="en">
	<head>
		<meta charset="UTF-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<title>Resultado</title>
		<style>
		body
		{
			background:#1c1c1c;
		}
		.container{
				margin:auto;
				width:50%
			}
		table{
			width:100%;
			color:white;
			text-align:center;
		}
		h4{
				color:white;
				text-align:center;
			}
			
		</style>
	</head>
	<body>
		<h4>TOTAL A PAGAR DE UN PRODUCTO</h4>
		<div class="container">
		<table class="egt">
		<tr>
			<th>CODIGO DE PRODUCTO</th>
			<th>NOMBRE DE PRODUCTO</th>
			<th>PRECIO</th>
			<th>IVA</th>
			<th>PRECIO SIN IVA</th>
			<th>TOTAL A PAGAR</th>
		</tr>
		<tr>
			<td><?php echo  $reult['cod']?></td>
			<td><?php echo  $reult['nombre']?></td>
			<td><?php echo  $reult['precio']?></td>
			<td><?php echo  $reult['iva']?></td>
			<td><?php echo  $reult['siniva']?></td>
			<td><?php echo  $reult['total']?></td>
		</tr>
		</table>
		</div>
	</body>
	</html>
	
	<?php

	

}else{
	?>
	<!DOCTYPE html>
	<html lang="en">
	<head>
		<meta charset="UTF-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<title>Calcular Pago</title>
		<style>
		body{
			background:#1c1c1c;
		}
			.container{
				margin:auto;
				width:25%
			}
			input, select{
				border:none;
				margin-bottom:25px;
				height:30px;
				width:100%

			} 
			h2{
				color:white;
				text-align:center;
			}
		</style>
	</head>
	<body>
		<div class="container">

		<h2>TOTAL A PAGAR DE UN PRODUCTO</h2>

		<form method = "POST" >
			<input placeholder = " Codigo de producto" type="text" name = "cod" required><br>
			<input placeholder = " Nombre del producto" type="text" name = "nombre" required><br>
			<input placeholder = " precio" type="number" name = "precio" required><br>
			<input  type="submit" value="Enviar">
		<form>
		</div>
	</body>
	</html>

<?php	
}
?>
