<?php
/****  
 * SERVIDOR WebService 
 *  Josseline Lemus 
 * esta carpeta es para el calculo del iva  de un producto.
 * para el calculo de retiro voluntario.
 * Si el sueldo es mayor de 1500; se calcula en base al 2 sueldos minimos 
 * Para calcular la indenizacion por retiro voluntario; es igual a 15 dias por la cantidad de años
 * *********/ 

date_default_timezone_set("America/El_Salvador");
require_once('nusoap/lib/nusoap.php');
$server = new nusoap_server;
$server->configureWSDL('server','urn:server');
$server->WSDL->schemaTargetNamespace= 'urn:server';

/*********REGISTRO DEL WEBSERVER PARA CALCULO DEL IVA DE UN PRODUCTO********** */
$server->wsdl->addComplexType(
    'Iva',
    'complexType',
    'struct',
    'all',
    '',
    array(
        'cod' => array('name' => 'cod', 'type' => 'xsd:string'),
        'nombre' => array('name' => 'nombre',    'type' => 'xsd:string'),
        'precio' => array('name' => 'precio', 'type' => 'xsd:float'),
        'siniva' => array('name' => 'siniva', 'type' => 'xsd:float'),
        'iva' => array('name' => 'iva',    'type' => 'xsd:float'),
        'total' => array('name' => 'total',    'type' => 'xsd:float')
    )
);
$server->register('totalIva',           // nombre método
    array(
    'cod' => 'xsd:string',
    'nombre' => 'xsd:string',
    'precio' => 'xsd:float',           //  parametros entrantes al servicio
    ),           
    array(
    'return' => 'tns:Iva'),       // valor(es) retornado(s)
    'urn:server',                      // namespace (espacio de nombre)
    'urn:server#holaServer',
    'rpc',
    'encoded',                                               // tipo de uso
    'Funcion para retornar el iva de un producto'    // documentación
    );

/*********REGISTRO DEL WEBSERVER PARA CALCULO DE RETIRO VOLUNTARIO********** */
$server->wsdl->addComplexType(
    'Empleado',
    'complexType',
    'struct',
    'all',
    '',
    array(
        'nombre' => array('name' => 'nombre', 'type' => 'xsd:string'),
        'cargo' => array('name' => 'cargo',    'type' => 'xsd:string'),
        'monto' => array('name' => 'sueldo', 'type' => 'xsd:float'),
        'anos' => array('name' => 'anos',    'type' => 'xsd:int'),
        'giro' => array('name' => 'giro',    'type' => 'xsd:string')
    )
);
$server->register('getPago',           // nombre método
    array(
    'nombre' => 'xsd:string',
    'cargo' => 'xsd:string',
    'sueldo' => 'xsd:float',
    'anos' => 'xsd:int',
    'giro' => 'xsd:string',
    ),            //  parametros entrantes al servicio
    array(
    'return' => 'tns:Empleado'),     // valor(es) retornado(s)
    'urn:server',                   // namespace (espacio de nombre)
    'urn:server#holaServer',
    'rpc',
    'encoded',                                                       // tipo de uso
    'Funcion para retornar el pago por retiro voluntario'    // documentación
    );
function getPago($nombre,$cargo,$sueldo,$anos,$giro)
{   
    if($sueldo>=1500){
        // Si el sueldo es mayor de 1500 
        // se calcula en base al 2 sueldos minimos 
        switch ($giro) {
            // Segun el giro se calcula en base al salario minimo de ese giro 
            case 'comercio': 
                $sueldoMinimo = 304.02;
                break;
            case 'industria':
                $sueldoMinimo = 300;
                break;    
            case 'maquila':
                $sueldoMinimo = 295;
                break;
            }
            $indemizacion = ($sueldoMinimo * 2) * $anos;
    }else{
        // Para calcular la indenizacion por retiro voluntario
        // Es igual a 15 dias por la cantidad de años
        $diastarabajados = 30;
        $sueldoQuincenal = ($sueldo / $diastarabajados) * 15;
        $indemizacion =  $sueldoQuincenal * $anos; 
    }

    // Se devuelve un array
    return array(
        'nombre' => $nombre,
        'cargo' => $cargo,
        'monto' => $indemizacion,
        'anos' => $anos,
        'giro' => $giro,
    );

}  
function totalIva($cod,$nombre,$precio)
{
    $sinIva = $precio / 1.13;  // EL iva en el salavador es 13% se divide entre 1.13 para obtener el precio sin iva 
    $iva = $precio - $sinIva; // Al precio se le resta el iva 
    
    return array(
        'cod' => $cod,
        'nombre' => $nombre,
        'precio' => $precio,
        'siniva' => round($sinIva,2),
        'iva' => round($iva,2),
        'total' => $precio,  // El precio es el total a pagar ya que el producto ya incluye el iva 
    );
}

//$HTTP_RAW_POST_DATA = isset($HTTP_RAW_POST_DATA) ? $HTTP_RAW_POST_DATA : ”;
//$server->service($HTTP_RAW_POST_DATA); NO FUNCIONA DESDE LA VERSIÓN 7.0 DE PHP

$server->service(file_get_contents("php://input")); //PARA CORRER EL SERVER DESDE LA VERSION 7.0

?>