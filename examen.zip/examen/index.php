<?php
/****  
 * CLIENTE WebService 
 * Josseline Lemus
 * esta carpeta es la del index para que cargue el formmulario; con los datos del empleado,cargo,sueldo,
 * años trabajados, y el rubro en el que desempeña
 * *********/ 
if (isset($_POST["nombre"])) {

	date_default_timezone_set("America/El_Salvador");
	require_once('nusoap/lib/nusoap.php');
	$wsdl = "http://localhost/examen/ws.php?wsdl";
	$client = new nusoap_client($wsdl,"wsdl");
	$err = $client->getError();
	if ($err) {
		echo '<h2>Constructor error</h2><pre>' . $err . '</pre>';
		exit();
	}
	$parametros = array(
        'nombre' =>$_POST["nombre"],
        'cargo' => $_POST["cargo"],
        'sueldo' => $_POST["sueldo"],
        'anos' =>  $_POST["anos"],
        'giro' =>  $_POST["giro"],
    );

	$reult = $client->call('getPago',$parametros);

	?>
	<!DOCTYPE html>
	<html lang="en">
	<head>
		<meta charset="UTF-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<title>Resultado</title>
		<style>
		body
		{
			background:#1c1c1c;
		}
		.container{
				margin:auto;
				width:50%
			}
		table{
			width:100%;
			color:white;
			text-align:center;
		}
		h4{
				color:white;
				text-align:center;
			}
			
		</style>
	</head>
	<body>
		<h4>PROGRAMA PARA CALCULAR EL PAGO POR RETIRO VOLUNTARIO</h4>
		<div class="container">
		<table class="egt">
		<tr>
			<th>NOMBRE DEL EMPLEADO</th>
			<th>CARGO</th>
			<th>MONTO A PAGAR</th>
			<th>AÑOS EN LA EMPRESA</th>
			<th>GIRO</th>
		</tr>
		<tr>
			<td><?php echo  $reult['nombre']?></td>
			<td><?php echo  $reult['cargo']?></td>
			<td><?php echo  $reult['monto']?></td>
			<td><?php echo  $reult['anos']?></td>
			<td><?php echo  $reult['giro']?></td>
		</tr>
		</table>
		</div>
	</body>
	</html>
	
	<?php

	

}else{
	?>
	<!DOCTYPE html>
	<html lang="en">
	<head>
		<meta charset="UTF-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<title>Calcular Pago</title>
		<style>
		body{
			background:#1c1c1c;
		}
			.container{
				margin:auto;
				width:25%
			}
			input, select{
				border:none;
				margin-bottom:25px;
				height:30px;
				width:100%

			} 
			h2{
				color:white;
				text-align:center;
			}
		</style>
	</head>
	<body>
		<div class="container">

		<h2>PROGRAMA PARA CALCULAR EL PAGO POR RETIRO VOLUNTARIO</h2>

		<form method = "POST" >
			<input placeholder = " Nombre de empleado" type="text" name = "nombre" required><br>
			<input placeholder = " Cargo de empleado" type="text" name = "cargo" required><br>
			<input placeholder = " Sueldo del empleado" type="number" name = "sueldo" required><br>
			<input placeholder = " Años trabajados por empleado" type="number" name = "anos" required><br>

			<select name="giro" id="giro">
				<option value="0">Seleccione el giro de la empresa</option>
				<option value="comercio">Comercio</option>
				<option value="industria">Industria</option>
				<option value="maquila">Maquila</option>
			</select>
			<input  type="submit" value="Enviar">
		<form>
		<a href="iva.php">TOTAL A PAGAR DE UN PRODUCTO ----></a>
		</div>
	</body>
	</html>

<?php	
}
?>
